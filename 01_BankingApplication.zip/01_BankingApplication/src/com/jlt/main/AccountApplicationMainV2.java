
package com.jlt.main;
import java.util.Scanner;import com.jlt.pojo.Account;
public class AccountApplicationMainV2 {
public static void main(String[] args) {
// Accept account number , name , balance from user and print account details.
Scanner scanner = new Scanner(System.in);
String continueChoice = "";
System.out.println("Enter account number");
int accountNumber = scanner.nextInt(); System.out.println("Enter Name");
String name = scanner.next(); System.out.println("Enter Balance");
double balance = scanner.nextDouble(); Account account = new Account(); account.setAccountNumber(accountNumber);
account.setBalance(balance);
account.setName(name); System.out.println("Account Details");
System.out.println("Account Number = " + account.getAccountNumber());
System.out.println("Name = " + account.getName());
System.out.println("Balance = " + account.getBalance()); do {
System.out.println("Menu");
System.out.println("Press 1: Withdraw");
System.out.println("Press 2: Deposite");
System.out.println("Press 3: Check Balance");
System.out.println("Enter your choice");
int choice = scanner.nextInt();
switch (choice) {
case 1: {
System.out.println("Enter the amount");
double amount = scanner.nextDouble();
boolean result = account.withdraw(amount);
if(result == true) {
System.out.println("Transaction Success");
} else {
System.out.println("Transaction Failed");
}
break;
}
case 2:{
System.out.println("Enter amount");
double amount = scanner.nextDouble();
if (account.deposite(amount))
System.out.println("Transaction Success");
else
System.out.println("Transaction Failed");
break;
}
case 3:{
System.out.println(account.getBalance());
break;
}
default:
System.out.println("Invalid choice");
break;
}
System.out.println("Do you want to continue?");
continueChoice = scanner.next();
}
while (continueChoice.equals("yes"));
}
}

