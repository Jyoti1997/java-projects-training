
package com.jlt.pojo;
//savings is a Account
public class Savings extends Account {
private boolean isSalary; public Savings() {
System.out.println("Default Constructor");
} public Savings(int accountNumber, String name, double balance, boolean isSalary) {
super(accountNumber, name, balance);
this.isSalary = isSalary;
System.out.println("Overloaded Constructor");
}
@Override
public boolean deposite(double amount) {
if (amount > 0) {
setBalance(getBalance() + amount);
return true;
}
return false;
}
@Override
public boolean withdraw(double amount) {
if (amount > 0 && isSalary && getBalance() - amount >= 0) {
setBalance(getBalance() - amount);
return true;
}
if (amount > 0 && isSalary == false && getBalance() - amount >= 1500) {
setBalance(getBalance() - amount);
return true;
}
return false;
}
}

