package com.jlt.main;

import java.util.Scanner;

import com.jlt.pojo.Account;
import com.jlt.pojo.Current;
import com.jlt.pojo.Savings;

public class AccountApplicationMainV7 {
	public static void main(String[] args) {
		int accountChoice;
		boolean isSalary;
		int accountNumber;
		String name;
		double balance;
		double overdraftBalance;
		int choice;
		double amount;
		boolean result = false;
		int continueChoice;

		Scanner scanner = new Scanner(System.in);
//		Savings savings = null;
//		Current current = null;

		Account account = null;

		System.out.println("Welcome to XYZ Bank");
		System.out.println("Account Choice");
		System.out.println("1.Savings");
		System.out.println("2. Current");

		accountChoice = scanner.nextInt();
		System.out.println("Enter account number");
		accountNumber = scanner.nextInt();

		System.out.println("Enter Name");
		name = scanner.next();

		System.out.println("Enter Balance");
		balance = scanner.nextDouble();

		switch (accountChoice) {
		case 1:
			System.out.println("Do you want to open Salary account");
			isSalary = scanner.nextBoolean();

			account = new Savings(accountNumber, name, balance, isSalary);
			System.out.println("Account Opened Successfully");

			break;
		case 2:
			System.out.println("Enter overdraft balance");
			overdraftBalance = scanner.nextDouble();

			account = new Current(accountNumber, name, balance, overdraftBalance);
			System.out.println("Account Opened Successfully");
		default:
			System.out.println("Invalid Choice");
			break;
		}
		System.out.println("Transaction Choice");

		do {
			System.out.println("Menu");
			System.out.println("Press 1. Withdraw");
			System.out.println("Press 2. Deposit");
			System.out.println("Press 3. Check Balance");

			System.out.println("Enter your choice");
			choice = scanner.nextInt();

			switch (choice) {
			case 1:
				System.out.println("Enter amount");
				amount = scanner.nextDouble();
				if (account.withdraw(amount)) {
					System.out.println("Transaction Success");
				} else {
					System.out.println("Transaction Failed");
				}
				break;
			case 2:
				System.out.println("Enter amount");
				amount = scanner.nextDouble();
				if (account.deposite(amount))
					System.out.println("Transaction Success");
				else
					System.out.println("Transaction Failed");
				break;
			case 3:
				if (accountChoice == 1) {
					System.out.println("Balance = " + account.getBalance());
				}
				if (accountChoice == 2) {
					System.out.println("Balance = " + account.getBalance());
					Current current = (Current) account;
					System.out.println("Overdraft Balance = " + current.getOverdraftBalance());
				}
				break;
			default:
				System.out.println("Invalid Choice");
				break;
			}
			System.out.println("Do you want to continue? Press 1 to contine");
			continueChoice = scanner.nextInt();
		} while (continueChoice == 1);
	}
}
