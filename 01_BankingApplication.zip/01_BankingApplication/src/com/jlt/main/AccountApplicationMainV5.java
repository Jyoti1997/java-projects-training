
package com.jlt.main;
import com.jlt.pojo.Current;
public class AccountApplicationMainV5 {
public static void main(String[] args) {
Current current = new Current(101, "Vivek Gohil", 10000, 50000);
// print details System.out.println("withdraw : 5000");
current.withdraw(5000);
System.out.println("Balance :: " + current.getBalance()); // 5000
System.out.println("Overdraft Balance :: " + current.getOverdraftBalance()); // 50000 System.out.println("---------------------------");
System.out.println("withdraw : 10000");
current.withdraw(10000);
System.out.println("Balance :: " + current.getBalance()); // 0
System.out.println("Overdraft Balance :: " + current.getOverdraftBalance()); // 45000 System.out.println("---------------------------");
System.out.println("deposit : 3000");
current.deposite(3000);
System.out.println("Balance :: " + current.getBalance()); // 0
System.out.println("Overdraft Balance :: " + current.getOverdraftBalance()); // 48000 System.out.println("---------------------------");
System.out.println("deposit : 10000");
current.deposite(10000);
System.out.println("Balance :: " + current.getBalance()); // 8000
System.out.println("Overdraft Balance :: " + current.getOverdraftBalance()); // 50000 }
}
}

