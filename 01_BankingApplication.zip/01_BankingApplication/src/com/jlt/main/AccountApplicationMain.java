
package com.jlt.main;
import com.jlt.pojo.Account;

public class AccountApplicationMain {
public static void main(String[] args) {
System.out.println("Hello World");
Account account = new Account();
// account.accountnNumber = 100;
// account.name = "Jyoti";
// account.balance = 1000;
//
// System.err.println(account.accountnNumber);
// System.err.println(account.name);
// System.err.println(account.balance);
account.setAccountNumber(100);
System.out.println("Account Number = " + account.getAccountNumber()); account.setName("Vivek Gohil");
System.out.println("Name = " + account.getName()); account.setBalance(1000);
System.out.println("Balance = " + account.getBalance());
}
}

