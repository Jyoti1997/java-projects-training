package com.jlt.pojo;

public class B extends A {
	public void show() {
		System.out.println("Hello");
	}
}
