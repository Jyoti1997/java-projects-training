package com.jlt.pojo;

import java.util.Scanner;

public class Calculation {
	private int number1, number2, result;
	private Scanner scanner = new Scanner(System.in);

	public void accept() {
		System.out.println("Enter Number1");
		number1 = scanner.nextInt();
		System.out.println("Enter Number2");
		number2 = scanner.nextInt();
	}

	public void calculate() {
		
		try {
			result = number1 / number2;
		}
		catch(ArithmeticException a)
		{
			System.out.println("Exception !!");
			System.out.println(a.getMessage());
		}
		finally
		{
			System.out.println("Result calculated !!");
		}
	}

	public void display() {
		System.out.println("Result = " + result);
	}
}
