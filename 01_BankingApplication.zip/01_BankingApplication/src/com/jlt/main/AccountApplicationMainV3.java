
package com.jlt.main;
import java.util.Scanner;import com.jlt.pojo.*;public class AccountApplicationMainV3 {
public static void main(String[] args) {
Scanner scanner = new Scanner(System.in);
String continueChoice = "";
System.out.println("Enter account number");
int accountNumber = scanner.nextInt(); System.out.println("Enter Name");
String name = scanner.next(); System.out.println("Enter Balance");
double balance = scanner.nextDouble();
Account account = new Account(accountNumber, name, balance);
System.out.println("Account Details");
System.out.println("Account Number = " + account.getAccountNumber());
System.out.println("Name = " + account.getName());
System.out.println("Balance = " + account.getBalance());
}
}

