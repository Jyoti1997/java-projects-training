package com.jlt.main;

import java.util.ArrayList;

import com.jlt.pojo.Employee;

public class EmployeeMain {
	public static void main(String[] args) {
		Employee employee = new Employee(101, "Vivek Gohil", 1000);
		System.out.println(employee);

		Employee employee2 = new Employee(102, "Kunal Waghmare", 1000);

		ArrayList<Employee> employeeList = new ArrayList<Employee>();
		employeeList.add(employee);
		employeeList.add(employee2);
		System.out.println("----------------");
		System.out.println(employeeList);
		System.out.println("----------------");
		for (Employee emp : employeeList) {
			System.out.println(emp);
		}

	}
}
