package com.jlt.main;
 
import java.util.Scanner;
 
import com.jlt.pojo.Employee;
import com.jlt.util.EmployeeCRUD;
 
public class EmployeeCRUDMain {
	public static void main(String[] args) {
		// Create Read Update Delete
 
		// Accept employeeId , name , salary from user
		// Store in employee object
		// Create object of EmployeeCRUD class and call the addEmployee and pass
		// employee object
		int employeeId;
		String name;
		double salary;
		int choice;
		String continueChoice;
 
		Scanner scanner = new Scanner(System.in);
		EmployeeCRUD employeeCRUD = new EmployeeCRUD();
		do {
			System.out.println("1. Add New Employee");
			System.out.println("2. Print All Employees");
			System.out.println("3. Update Existing Employee");
			System.out.println("4. Delete Employee");
			System.out.println("5. Retrive Single Employee");
			System.out.println("Enter your choice");
			choice = scanner.nextInt();
 
			switch (choice) {
			case 1:
				System.out.println("Enter EmployeeId");
				employeeId = scanner.nextInt();
				System.out.println("Name");
				name = scanner.next();
				System.out.println("Salary");
				salary = scanner.nextDouble();
 
				Employee employee = new Employee(employeeId, name, salary);
				if (employeeCRUD.addEmployee(employee))
					System.out.println("Employee added successfully");
				else
					System.out.println("Failed to add employee");
 
				break;
			case 2:
				for (Employee emp : employeeCRUD.getAllEmployees()) {
					System.out.println(emp);
				}
				break;
			case 3:
				System.out.println("Enter EmployeeId");
				employeeId = scanner.nextInt();
				System.out.println("New Name");
				name = scanner.next();
				System.out.println("Salary");
				salary = scanner.nextDouble();
				if (employeeCRUD.updateEmployeeName(employeeId, name, salary)) {
					System.out.println("Employee details updated successfully");
				} else
					System.out.println("No employee found");
				break;
			case 4:
				System.out.println("Enter EmployeeId");
				employeeId = scanner.nextInt();
				if (employeeCRUD.deleteEmployee(employeeId))
					System.out.println("Employee deleted successfully");
				else
					System.out.println("No employee found");
				break;
			case 5:
				System.out.println("Enter EmployeeId");
				employeeId = scanner.nextInt();
				Employee e = employeeCRUD.getEmployee(employeeId);
				if (e != null)
					System.out.println(e);
				else
					System.out.println("No employee found");
				break;
			default:
				System.out.println("Invalid Choice");
				break;
			}
			System.out.println("Do you want to continue?");
			continueChoice = scanner.next();
		} while (continueChoice.equals("yes"));
	}
 
}