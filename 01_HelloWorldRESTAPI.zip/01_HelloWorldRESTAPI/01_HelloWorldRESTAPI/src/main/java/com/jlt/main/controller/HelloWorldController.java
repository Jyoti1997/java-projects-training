package com.jlt.main.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


//URL :: http://localhost:8018/myrestapi

@RestController
@RequestMapping("myrestapi")
public class HelloWorldController {
	// http://localhost:8018/myrestapi/message
		@RequestMapping("message")
	public String printMessage() {
		return "Hello World From Spring Boot";
	}
}

