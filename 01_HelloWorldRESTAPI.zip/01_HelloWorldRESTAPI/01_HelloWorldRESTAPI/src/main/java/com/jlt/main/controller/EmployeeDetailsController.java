package com.jlt.main.controller;

import java.util.ArrayList;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.jlt.main.pojo.Employee;
import com.jlt.main.util.EmployeeCRUD;
// http://localhost:8018/employeeapi
@RestController
@RequestMapping("employeeapi")
public class EmployeeDetailsController {
	
	//  http://localhost:8018/employeeapi/1
	@RequestMapping(value = "{employeeId}", method = RequestMethod.GET)
	public Employee getEmployee(@PathVariable int employeeId) {
		EmployeeCRUD employeeCRUD = new EmployeeCRUD();
		Employee employee= employeeCRUD.getEmployee(employeeId);
		return employee;
		

	}
	
	//URL :: http://localhost:8018/employeeapi/employee
	@RequestMapping(value = "employee", method = RequestMethod.POST)
	public boolean addEmployee(@RequestBody Employee employee) {
		EmployeeCRUD employeeCRUD = new EmployeeCRUD();
		boolean result = employeeCRUD.addEmployee(employee);
		return result;
	}
	
	// http://localhost:8018/employeeapi/allemployees
		@RequestMapping(value = "allemployees", method = RequestMethod.GET)
		public ArrayList<Employee> getAllEmployees() {
			EmployeeCRUD employeeCRUD = new EmployeeCRUD();
			return employeeCRUD.getAllEmployees();
		}
	
	
	/*
	//http://localhost:8018/employeeapi/Jyoti
	@RequestMapping(value = "{name}", method = RequestMethod.POST)
	public String addEmployee(@PathVariable String name) {
		return "Employee added with name : " +name;
	}
	
	
	
	
/*	// http://localhost:8018/employeeapi/one
	@RequestMapping(value = "one", method = RequestMethod.GET)
	public String method1() {
		return "method1 called";
	}
	// http://localhost:8018/employeeapi/two
		@RequestMapping(value = "two", method = RequestMethod.POST)
	public String method2() {
		return "method2 called";
	}
		// http://localhost:8018/employeeapi/three
		@RequestMapping(value = "three", method = RequestMethod.PUT)
		public String method3() {
			return "method3 called";
		}
		
		// http://localhost:8018/employeeapi/four
				@RequestMapping(value = "four", method = RequestMethod.DELETE)
				public String method4() {
					return "method4 called";
				}*/
	
	
}
