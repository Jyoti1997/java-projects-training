package com.jlt.pojo;

public class A {
	public void show() {
		System.out.println("Hi");
	}
}