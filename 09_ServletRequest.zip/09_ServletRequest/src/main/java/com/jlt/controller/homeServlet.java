package com.jlt.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class homeServlet
 */
@WebServlet("/homeServlet")
public class homeServlet extends HttpServlet {
	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		String login_id,pass;
		
		login_id=request.getParameter("login");
		pass = request.getParameter("password");
		
		PrintWriter out = response.getWriter();
		
		if(login_id.equals("admin") && pass.equals("admin"))
		{
			out.println("Login successful");
		}
		else {
			out.println("Login Failed");

		}
	
		
		
		
		
		
	}
}
