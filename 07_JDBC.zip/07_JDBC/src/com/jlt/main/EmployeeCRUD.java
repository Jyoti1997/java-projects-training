package com.jlt.main;
 
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
 
public class EmployeeCRUD {
 
	private String url = "jdbc:sqlserver://localhost:1433;database=trainingDB;integratedSecurity=true";
	
	private String driver = "com.microsoft.sqlserver.jdbc.SQLServerDriver";
 
	private Connection connection;
	private PreparedStatement preparedStatement;
	private ResultSet resultSet;
 
	public static void main(String[] args) {
		EmployeeCRUD employeeCRUD = new EmployeeCRUD();
	 //employeeCRUD.addEmployee();
	 //employeeCRUD.updateEmployee();
		//employeeCRUD.deleteEmployee();
	//employeeCRUD.getSingleEmployee();
		employeeCRUD.getAllEmployees();
	}
	public void getAllEmployees() {
		try {
 
			Class.forName(driver);
			connection = DriverManager.getConnection(url);
			if (connection != null) {
				System.out.println("Connection success");
				preparedStatement = connection.prepareStatement("select * from employee_details");
 
				resultSet = preparedStatement.executeQuery();
 
				while (resultSet.next()) {
					int employee_id = resultSet.getInt("employee_id");
					String name = resultSet.getString("name");
					double salary = resultSet.getDouble("salary");
 
					System.out.println("Employee Id :: " + employee_id + " Name :: " + name + " Salary :: " + salary);
				}
			}
 
		} catch (ClassNotFoundException e) {
 
			System.out.println("Exception!!");
			System.out.println(e.getMessage());
 
		} catch (SQLException e) {
 
			System.out.println("Exception!!");
			System.out.println(e.getMessage());
 
		} finally {
			try {
				connection.close();
			} catch (SQLException e) {
				System.out.println("Exception!!");
				System.out.println(e.getMessage());
			}
		}
	}
	
	public void getSingleEmployee() {
		try {
			 
			Class.forName(driver);
			connection = DriverManager.getConnection(url);
			if (connection != null) {
				System.out.println("Connection success");
				preparedStatement = connection.prepareStatement("select * from employee_details where employee_id = ?");
				preparedStatement.setInt(1, 9);
 
				resultSet = preparedStatement.executeQuery();
 
				if (resultSet.next()) {
					int employee_id = resultSet.getInt("employee_id");
					String name = resultSet.getString("name");
					double salary = resultSet.getDouble("salary");
 
					System.out.println("Employee Id :: " + employee_id + " Name :: " + name + " Salary :: " + salary);
				}
			}
 
		} catch (ClassNotFoundException e) {
 
			System.out.println("Exception!!");
			System.out.println(e.getMessage());
 
		} catch (SQLException e) {
 
			System.out.println("Exception!!");
			System.out.println(e.getMessage());
 
		} finally {
			try {
				connection.close();
			} catch (SQLException e) {
				System.out.println("Exception!!");
				System.out.println(e.getMessage());
			}
		}
	}
 
 
	public void deleteEmployee() {
		try {
 
			Class.forName(driver);
			connection = DriverManager.getConnection(url);
			if (connection != null) {
				System.out.println("Connection success");
				preparedStatement = connection.prepareStatement("delete employee_details where employee_id = ?");
				preparedStatement.setInt(1, 10);
 
				int rowCount = preparedStatement.executeUpdate();
				System.out.println("Number of rows deleted :: " + rowCount);
			}
 
		} catch (ClassNotFoundException e) {
 
			System.out.println("Exception!!");
			System.out.println(e.getMessage());
 
		} catch (SQLException e) {
 
			System.out.println("Exception!!");
			System.out.println(e.getMessage());
 
		} finally {
			try {
				connection.close();
			} catch (SQLException e) {
				System.out.println("Exception!!");
				System.out.println(e.getMessage());
			}
		}
	}
 
	public void updateEmployee() {
		try {
 
			Class.forName(driver);
			connection = DriverManager.getConnection(url);
			if (connection != null) {
				System.out.println("Connection success");
				preparedStatement = connection.prepareStatement("update employee_details set name=? , salary = ? where employee_id = ?");
				preparedStatement.setString(1, "Trupti");
				preparedStatement.setDouble(2, 2000);
				preparedStatement.setInt(3, 9);
 
				int rowCount = preparedStatement.executeUpdate();
				System.out.println("Number of rows updated :: " + rowCount);
			}
 
		} catch (ClassNotFoundException e) {
 
			System.out.println("Exception!!");
			System.out.println(e.getMessage());
 
		} catch (SQLException e) {
 
			System.out.println("Exception!!");
			System.out.println(e.getMessage());
 
		} finally {
			try {
				connection.close();
			} catch (SQLException e) {
				System.out.println("Exception!!");
				System.out.println(e.getMessage());
			}
		}
	}
 
	public void addEmployee() {
		try {
 
			Class.forName(driver);
			connection = DriverManager.getConnection(url);
			if (connection != null) {
				System.out.println("Connection success");
				preparedStatement = connection.prepareStatement("insert into employee_details values(?,?)");
				preparedStatement.setString(1, "Vivek Gohil");
				preparedStatement.setDouble(2, 1000);
 
				int rowCount = preparedStatement.executeUpdate();
				System.out.println("Number of rows inserted :: " + rowCount);
			}
 
		} catch (ClassNotFoundException e) {
 
			System.out.println("Exception!!");
			System.out.println(e.getMessage());
 
		} catch (SQLException e) {
 
			System.out.println("Exception!!");
			System.out.println(e.getMessage());
 
		} finally {
			try {
				connection.close();
			} catch (SQLException e) {
				System.out.println("Exception!!");
				System.out.println(e.getMessage());
			}
		}
	}
}
 