package com.jlt.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/LifeCycleServlet")
public class LifeCycleServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public LifeCycleServlet() {
    	System.out.println("object created");
       // super();
    }

	
	public void init(ServletConfig config) throws ServletException {
	System.out.println("Init method called");
	}

	
	public void destroy() {
	
		System.out.println("destroy method called");

	}

	
	protected void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		System.out.println("service method called");
		
		PrintWriter Writer = response.getWriter();
		Writer.println("Hello world servlet");

	}
}
