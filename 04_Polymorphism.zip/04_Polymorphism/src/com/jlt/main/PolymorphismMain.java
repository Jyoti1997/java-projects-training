package com.jlt.main;

import com.jlt.pojo.A;
import com.jlt.pojo.B;
import java.util.Scanner;


public class PolymorphismMain {
	public static void main(String[] args) {
		int choice;
		A obja = null;
		System.out.println("Enter choice");
		choice = new Scanner(System.in).nextInt();

		switch (choice) {
		case 1:
			obja = new A();
			break;
		case 2:
			// Dynamic Binding , Late binding
			obja = new B();
			break;
		}

		// Polymorphic Call
		obja.show();
	}
}

